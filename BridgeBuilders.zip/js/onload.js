window.addEventListener("load", async function () {
	const video = document.querySelector("#autoplay")
	await video.play()
})
